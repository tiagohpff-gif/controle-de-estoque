"""
SISTEMA DE ESTOQUE - app.py
============================
Este arquivo é o "cérebro" do sistema. Ele:
1. Conecta com o banco de dados (SQLite)
2. Define as ROTAS (URLs) que o navegador pode acessar
3. Processa os formulários (entrada/saída de estoque)

Conceitos Python usados aqui: funções, dicionários, SQL básico,
manipulação de arquivos, decoradores (@app.route).
"""

from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)

# --- Caminhos importantes ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "estoque.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "images")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


def get_db():
    """Abre uma conexão com o banco de dados.
    row_factory faz cada linha se comportar como um dicionário
    (ex: produto["nome"] em vez de produto[0])."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Cria as tabelas se elas ainda não existirem, e cadastra
    Coca-Cola, Pepsi e Fanta automaticamente na primeira execução."""
    conn = get_db()

    # Tabela de produtos: cada linha é um item do estoque
    conn.execute("""
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE,
            imagem TEXT,
            quantidade INTEGER NOT NULL DEFAULT 0
        )
    """)

    # Tabela de movimentos: histórico de TODA entrada e saída
    # (guardamos isso separado da tabela de produtos pra nunca
    # perder o histórico, mesmo quando o estoque muda)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS movimentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER NOT NULL,
            tipo TEXT NOT NULL CHECK(tipo IN ('entrada','saida')),
            quantidade INTEGER NOT NULL,
            data TEXT NOT NULL,
            FOREIGN KEY (produto_id) REFERENCES produtos(id)
        )
    """)

    # Produtos iniciais (só insere se ainda não existirem)
    produtos_iniciais = [
        ("Coca-Cola", "coca_cola.png"),
        ("Pepsi", "pepsi.png"),
        ("Fanta", "fanta.png"),
    ]
    for nome, imagem in produtos_iniciais:
        conn.execute(
            "INSERT OR IGNORE INTO produtos (nome, imagem, quantidade) VALUES (?, ?, 0)",
            (nome, imagem)
        )

    conn.commit()
    conn.close()


@app.route("/")
def index():
    """Página principal: lista todos os produtos com a quantidade atual."""
    conn = get_db()
    produtos = conn.execute("SELECT * FROM produtos ORDER BY nome").fetchall()
    conn.close()
    return render_template("index.html", produtos=produtos)


@app.route("/movimentar", methods=["POST"])
def movimentar():
    """Recebe o formulário de entrada/saída, atualiza a quantidade
    e grava um registro no histórico de movimentos."""
    produto_id = request.form["produto_id"]
    tipo = request.form["tipo"]  # "entrada" ou "saida"
    quantidade = int(request.form["quantidade"])

    conn = get_db()
    produto = conn.execute(
        "SELECT * FROM produtos WHERE id = ?", (produto_id,)
    ).fetchone()

    if tipo == "entrada":
        nova_quantidade = produto["quantidade"] + quantidade
    else:  # saida
        nova_quantidade = produto["quantidade"] - quantidade
        if nova_quantidade < 0:
            nova_quantidade = 0  # nunca deixa o estoque ficar negativo

    conn.execute(
        "UPDATE produtos SET quantidade = ? WHERE id = ?",
        (nova_quantidade, produto_id)
    )
    conn.execute(
        "INSERT INTO movimentos (produto_id, tipo, quantidade, data) VALUES (?, ?, ?, ?)",
        (produto_id, tipo, quantidade, datetime.now().strftime("%d/%m/%Y %H:%M"))
    )
    conn.commit()
    conn.close()

    return redirect(url_for("index"))


@app.route("/produto/novo", methods=["GET", "POST"])
def novo_produto():
    """Formulário para cadastrar um novo produto, com upload de imagem."""
    if request.method == "POST":
        nome = request.form["nome"]
        imagem_file = request.files.get("imagem")
        nome_arquivo = None

        if imagem_file and imagem_file.filename:
            nome_arquivo = secure_filename(imagem_file.filename)
            imagem_file.save(os.path.join(app.config["UPLOAD_FOLDER"], nome_arquivo))

        conn = get_db()
        conn.execute(
            "INSERT INTO produtos (nome, imagem, quantidade) VALUES (?, ?, 0)",
            (nome, nome_arquivo)
        )
        conn.commit()
        conn.close()
        return redirect(url_for("index"))

    return render_template("add_product.html")


@app.route("/historico/<int:produto_id>")
def historico(produto_id):
    """Mostra o histórico de entradas/saídas de um produto específico."""
    conn = get_db()
    produto = conn.execute(
        "SELECT * FROM produtos WHERE id = ?", (produto_id,)
    ).fetchone()
    movimentos = conn.execute(
        "SELECT * FROM movimentos WHERE produto_id = ? ORDER BY id DESC",
        (produto_id,)
    ).fetchall()
    conn.close()
    return render_template("historico.html", produto=produto, movimentos=movimentos)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
