# Controle de Estoque - Coca-Cola / Pepsi / Fanta

## Como rodar na sua máquina

1. Instale o Python (se ainda não tiver): https://www.python.org/downloads/
2. Abra o terminal dentro da pasta `estoque_app`
3. Instale o Flask:
   ```
   pip install flask
   ```
4. Rode o servidor:
   ```
   python app.py
   ```
5. Abra o navegador em: http://127.0.0.1:5000

O banco de dados (`estoque.db`) é criado automaticamente na primeira
execução, já com Coca-Cola, Pepsi e Fanta cadastrados com estoque 0.

## Estrutura do projeto

```
estoque_app/
├── app.py                  <- lógica do sistema (Python/Flask)
├── estoque.db               <- banco de dados (criado sozinho)
├── templates/
│   ├── index.html            <- página principal
│   ├── add_product.html      <- cadastro de produto
│   └── historico.html        <- histórico de movimentos
└── static/
    ├── style.css              <- visual do site
    └── images/                <- fotos dos produtos
```

## O que fazer em seguida (sugestões de estudo)

- Adicionar um campo "estoque mínimo" e alertar quando acabar
- Trocar SQLite por MySQL/PostgreSQL (bancos usados em produção)
- Adicionar login de usuário
- Gerar relatório em PDF ou Excel do histórico
